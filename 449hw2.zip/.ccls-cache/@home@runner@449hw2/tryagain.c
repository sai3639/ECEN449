//#include <stdio.h>
//#include <string>
//#define MAX_LINES 100
// max character length in a file
//#define MAX_LEN 1000

// void reversewords(char *str){
//  int len = strlen(str);
//  char temp1[100];

// char data[MAX_LINES][MAX_LEN];
// keep track of current line being read
// int line = 0;
//}

// int main(void) {
//  char *filename = "IN.txt";
//  file pointer variable - open file
// FILE *fp = fopen(filename, "read");

//  if (fp == NULL) {
//  printf("error opening file %s", filename);
// return 1;
//}

// const unsigned MAX_LENGTH = 256;
// char buffer[MAX_LENGTH];
// while (fgets(buffer, MAX_LENGTH, fp)) {
//   printf("%s", buffer);
// }
// fclose(fp);

// reversewords(str);

// return 0;
//}