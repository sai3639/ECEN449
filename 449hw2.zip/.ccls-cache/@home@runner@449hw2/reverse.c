#include <stdio.h>
#include <string.h>

#define MAX_LENGTH 1000 // Assuming the input line won't exceed 1000 characters

void reverseWords(char *str) {
  int len = strlen(str);
  char temp[len + 1]; // Create a temporary array to store the reversed string
  int word_start = len, word_end = len;
  int i, j = 0;

  // Traverse the string from the end to the beginning
  for (i = len - 1; i >= 0; i--) {
    if (str[i] == ' ' || i == 0) {
      if (i == 0) {
        word_start = i; // Include the first character
      } else {
        word_start = i + 1;
      }

      // Copy the word into the temporary array
      while (word_start < word_end) {
        temp[j++] = str[word_start++];
      }

      // Add space between words, except after the last word
      if (i != 0) {
        temp[j++] = ' ';
      }

      word_end = i; // Move the word end to the current position
    }
  }

  temp[j] = '\0'; // Null-terminate the string

  // Copy the reversed string back into the original array
  strcpy(str, temp);
}

int main() {
  FILE *inputFile, *outputFile;
  char str[MAX_LENGTH];

  // Open the input file for reading
  inputFile = fopen("IN.txt", "r");
  if (inputFile == NULL) {
    printf("Error opening IN.txt for reading\n");
    return 1;
  }

  // Read the single line from the input file
  if (fgets(str, MAX_LENGTH, inputFile) == NULL) {
    printf("Error reading from IN.txt\n");
    fclose(inputFile);
    return 1;
  }

  // Close the input file
  fclose(inputFile);

  // Reverse the words in the string
  reverseWords(str);

  // Open the output file for writing
  outputFile = fopen("OUT.txt", "w");
  if (outputFile == NULL) {
    printf("Error opening OUT.txt for writing\n");
    return 1;
  }

  // Write the reversed string to the output file
  fprintf(outputFile, "%s", str);

  // Close the output file
  fclose(outputFile);

  printf("String successfully reversed and written to OUT.txt\n");

  return 0;
}
