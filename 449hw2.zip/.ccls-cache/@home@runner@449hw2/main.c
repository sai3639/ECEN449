#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LEN 1000  // Maximum length of the input line

void reverse_words(char *str) {
    int len = strlen(str);
    int start = 0, end = len - 1;

    // Reverse the entire string
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }

    // Reverse each word in the reversed string
    int word_start = 0, word_end = 0;
    while (word_end <= len) {
        //space or end of string - word 
        if (str[word_end] == ' ' || str[word_end] == '\0') {
            int ws = word_start, we = word_end - 1;
            // Reverse the word
            while (ws < we) {
                char temp = str[ws];
                str[ws] = str[we];
                str[we] = temp;
                ws++;
                we--;
            }
            word_start = word_end + 1;  // Move to the next word
        }
        word_end++;
    }
}

int main() {
    FILE *input_file, *output_file;
    char line[MAX_LEN];

    // Open the input file for reading
    input_file = fopen("IN.txt", "r");
    if (input_file == NULL) {
        perror("Error opening input file");
        return 1;
    }

    // Read the line from the input file
    if (fgets(line, MAX_LEN, input_file) == NULL) {
        perror("Error reading from input file");
        fclose(input_file);
        return 1;
    }
    fclose(input_file);  // Close the input file after reading

    // Reverse the words in the line
    reverse_words(line);

    // Open the output file for writing
    output_file = fopen("OUT.txt", "w");
    if (output_file == NULL) {
        perror("Error opening output file");
        return 1;
    }

    // Write the reversed string to the output file
    fputs(line, output_file);
    fclose(output_file);  // Close the output file after writing

    printf("Reversed string has been written to OUT.txt\n");
    return 0;
}
